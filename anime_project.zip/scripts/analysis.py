import os
import shutil
import pandas as pd

# Chargement du jeu de données
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
data_path = os.path.join(base_dir, 'data', 'animes.csv')
df = pd.read_csv(data_path)

# Conversion des colonnes
if 'Score' in df.columns:
    df['Score'] = pd.to_numeric(df['Score'], errors='coerce')
if 'Popularity' in df.columns:
    df['Popularity'] = pd.to_numeric(df['Popularity'], errors='coerce')

# Gestion des valeurs manquantes
df['Score'].fillna(df['Score'].mean(), inplace=True)
df['Popularity'].fillna(df['Popularity'].max(), inplace=True)

# Suppression des doublons
df = df.drop_duplicates()

# Inversion de la popularité pour que les valeurs élevées correspondent à une meilleure popularité
pop_norm = df['Popularity'].max() - df['Popularity'] + 1

# Calcul du score final
df['score_final'] = 0.6 * df['Score'] + 0.4 * pop_norm

# Tri et sélection du Top 10
top10 = df.sort_values(by='score_final', ascending=False).head(10)

# Sauvegarde du Top 10
output_path = os.path.join(base_dir, 'data', 'top10.csv')
top10.to_csv(output_path, index=False)

print('Top 10 généré et sauvegardé dans', output_path)
