# Projet Anime Dataset

Ce dépôt contient un exemple de traitement du jeu de données `animes.csv`.  
Les principales étapes sont :

1. Charger le fichier CSV avec `pandas`.
2. Nettoyer les données : convertir les colonnes en types numériques, gérer les valeurs manquantes et supprimer les doublons.
3. Créer un score final combinant la note (`Score`) et la popularité (`Popularity`). On inverse d'abord la popularité (un rang plus petit devient une valeur plus grande), puis on calcule `score_final = 0.6 * Score + 0.4 * pop_norm`.
4. Trier les animés selon `score_final` et sauvegarder le Top 10 dans `top10.csv`.

Exécutez `python scripts/analysis.py` depuis la racine du projet pour obtenir le classement.

